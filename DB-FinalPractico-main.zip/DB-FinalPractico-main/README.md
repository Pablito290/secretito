# DB-FinalPractico

Integrantes:
-Giulia Alexa Naval Fernández
-Rodrigo Alonso Torres Sotomayor
-Gabriel Alexander Valdivia Medina
-Pablo Luis Carazas Barrios

