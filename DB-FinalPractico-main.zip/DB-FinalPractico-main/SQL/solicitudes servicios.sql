INSERT INTO solicitudes_srvcios (id_cargo, id_servicio)
VALUES (1, 3);

INSERT INTO solicitudes_srvcios (id_cargo, id_servicio)
VALUES (2, 3);

INSERT INTO solicitudes_srvcios (id_cargo, id_servicio)
VALUES (3, 5);

INSERT INTO solicitudes_srvcios (id_cargo, id_servicio)
VALUES (4, 7);

INSERT INTO solicitudes_srvcios (id_cargo, id_servicio)
VALUES (4, 8);

INSERT INTO solicitudes_srvcios (id_cargo, id_servicio)
VALUES (2, 6);

INSERT INTO solicitudes_srvcios (id_cargo, id_servicio)
VALUES (1, 4);

INSERT INTO solicitudes_srvcios (id_cargo, id_servicio)
VALUES (5, 2);

INSERT INTO solicitudes_srvcios (id_cargo, id_servicio)
VALUES (2, 1);