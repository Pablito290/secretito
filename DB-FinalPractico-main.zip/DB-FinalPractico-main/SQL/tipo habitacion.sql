INSERT INTO tipo_habitacion(nombre_tipo, costo_hab, descripcion, capacidad)
VALUES ('simple', 115, NULL, 1);

INSERT INTO tipo_habitacion (nombre_tipo, costo_hab, descripcion, capacidad)
VALUES ('doble', 135, 'Dos camas separadas', 2);

INSERT INTO tipo_habitacion (nombre_tipo, costo_hab, descripcion, capacidad)
VALUES ('triple', 300, NULL, 3);

INSERT INTO tipo_habitacion (nombre_tipo, costo_hab, descripcion, capacidad)
VALUES ('matrimonial', 130, 'Una cama para 2', 2);

INSERT INTO tipo_habitacion (nombre_tipo, costo_hab, descripcion, capacidad)
VALUES ('VIP simple', 350, NULL, 1);

INSERT INTO tipo_habitacion (nombre_tipo, costo_hab, descripcion, capacidad)
VALUES ('VIP matrimonial', 500, 'Una cama para 2', 2);
