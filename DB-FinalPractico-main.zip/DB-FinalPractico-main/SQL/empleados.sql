INSERT INTO cargos_personal(nombre_cargo)
VALUES ('jefe administrativo');
INSERT INTO cargos_personal(nombre_cargo)
VALUES ('jefe de comunicaciones');
INSERT INTO cargos_personal(nombre_cargo)
VALUES ('jefe de relaciones');
INSERT INTO cargos_personal(nombre_cargo)
VALUES ('jefe de seguridad');
INSERT INTO cargos_personal(nombre_cargo)
VALUES ('jefe de cocina');
INSERT INTO cargos_personal(nombre_cargo)
VALUES ('jefe de limpieza');
INSERT INTO cargos_personal(nombre_cargo)
VALUES ('jefe de cochera');
INSERT INTO cargos_personal(nombre_cargo)
VALUES ('recepcionista');
INSERT INTO cargos_personal(nombre_cargo)
VALUES ('asistente de teléfono');
INSERT INTO cargos_personal(nombre_cargo)
VALUES ('vigilante');
INSERT INTO cargos_personal(nombre_cargo)
VALUES ('vigilante de cámaras');
INSERT INTO cargos_personal(nombre_cargo)
VALUES ('cocinero');
INSERT INTO cargos_personal(nombre_cargo)
VALUES ('mesero');
INSERT INTO cargos_personal(nombre_cargo)
VALUES ('conserje');
INSERT INTO cargos_personal(nombre_cargo)
VALUES ('valet de cochera');

INSERT INTO personal
VALUES ('76215438', 'Adán', 'Cabello', 1, '325698745', 'administracion',
		'Maestría de negocios', NULL);
INSERT INTO personal
VALUES ('76259843', 'Victoria', 'Echevarría', 2, '656987412', 'comunicaciones',
		'Maestría en com.', NULL);
INSERT INTO personal
VALUES ('76253698', 'Sundara', 'Guerrero', 3, '986532145', 'relaciones',
		'Academica de diplomacia', NULL);
INSERT INTO personal
VALUES ('74258613', 'Maikel', 'De la Fuente', 4, '968574021', 'seguridad',
		NULL, NULL);
INSERT INTO personal
VALUES ('70365920', 'Carlito', 'Pérez', 5, '903625012', 'cocina',
		'Grado Gastronomía', NULL);
INSERT INTO personal
VALUES ('60231450', 'Mneme', 'Vicario', 6, '863021504', 'limpieza',
		NULL, NULL);
INSERT INTO personal
VALUES ('60321547', 'Adelardo', 'Cuesta', 8, '963201352', 'administracion',
		'Grado de admin.', 'Recepcion principal');
INSERT INTO personal
VALUES ('50216385', 'Ercilia', 'Torres', 9, '863251486', 'comunicaciones',
		'grado comunicaciones', 'Teléfono 1');
INSERT INTO personal
VALUES ('86935269', 'Kalliope', 'Otero', 9, '960356920', 'comunicaciones',
		'grado comunicaciones', 'Teléfono 2');
INSERT INTO personal
VALUES ('96235810', 'Heracles', 'Tos', 10, '986325693', 'seguridad',
		NULL, 'puerta principal');
INSERT INTO personal
VALUES ('96325618', 'Daireann', 'Sánchez', 10, '963254105', 'seguridad',
		NULL, 'puerta secundaria');
INSERT INTO personal
VALUES ('75032658', 'Kassandra', 'Olmo', 11, '963250123', 'seguridad',
		'tecnico tecnologia', NULL);
INSERT INTO personal
VALUES ('82036510', 'Justina', 'León', 12, '963021352', 'cocina',
		'grado gastronomía', 'cocina 1');
INSERT INTO personal
VALUES ('82013568', 'Adelita', 'Oquendo', 12, '856320369', 'cocina',
		'grado gastronomía', 'cocina 2');
INSERT INTO personal
VALUES ('85201352', 'Eneida', 'Guzmán', 13, '963021350', 'cocina',
		NULL, 'cocina 1');
INSERT INTO personal
VALUES ('96302315', 'Lada', 'Maradona', 13, '963025398', 'cocina',
		NULL, 'cocina 1');
INSERT INTO personal
VALUES ('85203168', 'Tisiphone', 'Rana', 13, '963023015', 'cocina',
		NULL, 'cocina 2');
INSERT INTO personal
VALUES ('82036598', 'Sofronio', 'Vicente', 13, '596303658', 'cocina',
		NULL, 'cocina 2');
INSERT INTO personal
VALUES ('96302159', 'Anoubis', 'Echevarría', 14, '951230564', 'limpieza',
		NULL, 'piso 1');
INSERT INTO personal
VALUES ('84230658', 'Trini', 'Gómez', 14, '963201563', 'limpieza',
		NULL, 'piso 2');
INSERT INTO personal
VALUES ('85230124', 'Juventas', 'Giménez', 14, '960147352', 'limpieza',
		NULL, 'piso 3');
INSERT INTO personal
VALUES ('85236012', 'Salacia', 'Castro', 15, '930126845', 'cochera',
		NULL, NULL);
INSERT INTO personal
VALUES ('82031650', 'Pythios', 'Velasco', 15, '963023014', 'cochera',
		NULL, NULL);