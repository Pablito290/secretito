INSERT INTO lista_prsnal_srvcio(id_personal, id_servicio)
VALUES ('50216385', 4);

INSERT INTO lista_prsnal_srvcio(id_personal, id_servicio)
VALUES ('60231450', 5);

INSERT INTO lista_prsnal_srvcio(id_personal, id_servicio)
VALUES ('96302159', 5);

INSERT INTO lista_prsnal_srvcio(id_personal, id_servicio)
VALUES ('70365920', 6);

INSERT INTO lista_prsnal_srvcio(id_personal, id_servicio)
VALUES ('85201352', 6);

INSERT INTO lista_prsnal_srvcio(id_personal, id_servicio)
VALUES ('74258613', 7);

INSERT INTO lista_prsnal_srvcio(id_personal, id_servicio)
VALUES ('82031650', 8);

INSERT INTO lista_prsnal_srvcio(id_personal, id_servicio)
VALUES ('60321547', 1);

INSERT INTO lista_prsnal_srvcio(id_personal, id_servicio)
VALUES ('60321547', 2);

INSERT INTO lista_prsnal_srvcio(id_personal, id_servicio)
VALUES ('60321547', 3);
/*nuevo*/
INSERT INTO lista_prsnal_srvcio(id_personal, id_servicio)
VALUES ('76215438', 1);
INSERT INTO lista_prsnal_srvcio(id_personal, id_servicio)
VALUES ('76215438', 2);
INSERT INTO lista_prsnal_srvcio(id_personal, id_servicio)
VALUES ('76215438', 3);
INSERT INTO lista_prsnal_srvcio(id_personal, id_servicio)
VALUES ('76259843', 4);
INSERT INTO lista_prsnal_srvcio(id_personal, id_servicio)
VALUES ('96235810', 7);





