INSERT INTO huespedes 
VALUES ('635987462' ,'Anton', 'Ego','998563214','ratatouilleEater@gmail.com','1','Francia');

INSERT INTO huespedes
VALUES ('365984126', 'eena', 'Stacks', '963257462', 'gnstcks@outlook.com','0','EEUU');

INSERT INTO huespedes
VALUES ('124865743', 'FLannery', 'Mynatt', '931648722', 'flnyMnt@protonmail.com', '1', 'Francia');

INSERT INTO huespedes
VALUES ('164258379', 'Ascanio', 'Polley', '963254132', 'asCpllY@gmail.com', '0', 'Italia');

INSERT INTO huespedes
VALUES ('415236987', 'Godfrey', 'Parker', '856321456', 'GODprkr@yahoo.com', '0', 'EEUU');

INSERT INTO huespedes
VALUES ('172839654', 'Rheanna', 'Righi', '215756325', 'rhNgg@gmail.com', '1', 'England');

INSERT INTO huespedes
VALUES ('582645719', 'Scottie', 'Elmer', '985632147', 'sCCtlmr@gmail.com', '0', 'EEUU');

INSERT INTO huespedes
VALUES ('75632598', 'Jamsheed', 'Pinto', '986532145', 'jmmmp@hotmail.com', '0', NULL);

INSERT INTO huespedes
VALUES ('917356482', 'Firmino', 'Paternoster', '6352589541', 'frtstr01@protonmail.com', '1', 'Greece');

INSERT INTO huespedes
VALUES ('369852147', 'Micah', 'Patton', '963258741', 'mcpt@gmail.com', '0', 'EEUU');

INSERT INTO huespedes
VALUES ('951575356', 'Christy', 'Durán', '952361323', 'ChrtDr@outlook.com', '1', 'EEUU');

INSERT INTO huespedes
VALUES ('123927286', 'Mercurius', 'Bianco', '512689354', 'MrcBc@gmail.com', '0', 'Italia');

INSERT INTO huespedes
VALUES ('175428634', 'Buster', 'Priestley', '632541789', 'BustPrtsl@hotmail.com', '0', 'EEUU');

INSERT INTO huespedes
VALUES ('682359641', 'Madilyn', 'Little', '953214786', 'MdlLt@gmail.com', '0', 'EEUU');

INSERT INTO huespedes
VALUES ('145236521', 'Alberich', 'Collins', '963258413', 'AlbC@yahoo.com', '0', 'England');

INSERT INTO huespedes
VALUES ('718293656', 'Shanae', 'Whittemore', '625436982', 'shnw31@gmail.com', '0', 'EEUU');

INSERT INTO huespedes
VALUES ('415263735', 'Ameretat', 'Martínez', '963254139', 'marti65@hotmail.com', '1', 'España');

INSERT INTO huespedes
VALUES ('102305462', 'Madhavi', 'Luna', '965213487', 'moonD@outlook.com', '0', 'España');

INSERT INTO huespedes
VALUES ('75142369', 'Feidelm', 'Salcedo', '968745369', 'fsalced@gmail.com', '1', NULL);