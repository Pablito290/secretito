INSERT INTO gerentes_generales
VALUES ('76325981', 1, 'Humberto', 'Lozano', '963201456', 'hmblx@gmail.com'); 

INSERT INTO gerentes_generales
VALUES ('85632014', 1, 'Cándido', 'Pardo', '963201456', 'Csnpr@gmail.com'); 

INSERT INTO gerentes_generales
VALUES ('45968325', 1, 'Usha', 'Arriola', '963201456', 'ush001@gmail.com'); 

INSERT INTO gerentes_generales
VALUES ('12365012', 1, 'Hadad', 'Cervantes', '963201456', '16843@gmail.com'); 

INSERT INTO gerentes_generales
VALUES ('76203256', 1, 'Vicenta', 'Alonso', '963201456', 'VicAl@outlook.com'); 