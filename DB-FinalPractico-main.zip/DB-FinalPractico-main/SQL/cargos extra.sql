INSERT INTO cargos_extra(id_reserva)
VALUES(1);

INSERT INTO cargos_extra(id_reserva)
VALUES(2);

INSERT INTO cargos_extra(id_reserva)
VALUES(3);

INSERT INTO cargos_extra(id_reserva)
VALUES(4);

INSERT INTO cargos_extra(id_reserva)
VALUES(8);
