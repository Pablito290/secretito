INSERT INTO reserva_huespedes (id_huesped, id_reserva)
VALUES ('635987462', 1);

INSERT INTO reserva_huespedes (id_huesped, id_reserva)
VALUES ('365984126', 1);

INSERT INTO reserva_huespedes (id_huesped, id_reserva)
VALUES ('124865743', 3);

INSERT INTO reserva_huespedes (id_huesped, id_reserva)
VALUES ('164258379', 1);

INSERT INTO reserva_huespedes (id_huesped, id_reserva)
VALUES ('415236987', 3);

INSERT INTO reserva_huespedes (id_huesped, id_reserva)
VALUES ('172839654', 2);

INSERT INTO reserva_huespedes (id_huesped, id_reserva)
VALUES ('582645719', 3);

INSERT INTO reserva_huespedes (id_huesped, id_reserva)
VALUES ('75632598', 7);

INSERT INTO reserva_huespedes (id_huesped, id_reserva)
VALUES ('917356482', 4);