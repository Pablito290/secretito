INSERT INTO reservas_vinculadas(id_habitacion, id_reserva)
VALUES (1,1);

INSERT INTO reservas_vinculadas(id_habitacion, id_reserva)
VALUES (2,2);

INSERT INTO reservas_vinculadas(id_habitacion, id_reserva)
VALUES (3,3);

INSERT INTO reservas_vinculadas(id_habitacion, id_reserva)
VALUES (4,3);

INSERT INTO reservas_vinculadas(id_habitacion, id_reserva)
VALUES (5,4);

INSERT INTO reservas_vinculadas(id_habitacion, id_reserva)
VALUES (6,5);

INSERT INTO reservas_vinculadas(id_habitacion, id_reserva)
VALUES (7,5);

INSERT INTO reservas_vinculadas(id_habitacion, id_reserva)
VALUES (8,5);

INSERT INTO reservas_vinculadas(id_habitacion, id_reserva)
VALUES (9,6);

INSERT INTO reservas_vinculadas(id_habitacion, id_reserva)
VALUES (10,7);

INSERT INTO reservas_vinculadas(id_habitacion, id_reserva)
VALUES (11,8);

/*no pueden haber null values, es el historial de reservas en las que se utilizó la habitación*/