INSERT INTO agencias (nombre_agencia, telefono, nombre_contacto,
					apellido_contacto, pctje_comision)
VALUES ('Experia Group', '365924', 'Suellen', 'Jeanes', 0.3);

INSERT INTO agencias(nombre_agencia, telefono, nombre_contacto,
					apellido_contacto, pctje_comision)
VALUES ('The French Travel', '632015', 'Richard', 'Nye', 0.25);

INSERT INTO agencias(nombre_agencia, telefono, nombre_contacto,
					apellido_contacto, pctje_comision)
VALUES ('BCD Travel', '630253', 'Valentine', 'Riley', 0.2);

INSERT INTO agencias(nombre_agencia, telefono, nombre_contacto,
					apellido_contacto, pctje_comision)
VALUES ('Travel Group Perú', '852031', 'Prudencio', 'Oquendo', 0.15);