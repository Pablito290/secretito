INSERT INTO tipo_servicio(nombre_servicio)
VALUE('Evento');

INSERT INTO tipo_servicio(nombre_servicio)
VALUE('Recreación');

INSERT INTO tipo_servicio(nombre_servicio)
VALUE('Mantenimiento_limpieza');

INSERT INTO tipo_servicio(nombre_servicio)
VALUE('Restaurante');

INSERT INTO tipo_servicio(nombre_servicio)
VALUE('Seguridad');

INSERT INTO tipo_servicio(nombre_servicio)
VALUE('Parking');