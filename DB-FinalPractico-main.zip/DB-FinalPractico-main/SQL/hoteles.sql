INSERT INTO hoteles (nombre_hotel, direccion)
VALUES ('Central Hotel', 'Av. Street k-25');