INSERT INTO habitaciones(id_reserva_actual, id_hotel, id_tipo_hab)
VALUES (1, 1, 2);

INSERT INTO habitaciones(id_reserva_actual, id_hotel, id_tipo_hab)
VALUES (2, 1, 1);

INSERT INTO habitaciones(id_reserva_actual, id_hotel, id_tipo_hab)
VALUES (3, 1, 4);

INSERT INTO habitaciones(id_reserva_actual, id_hotel, id_tipo_hab)
VALUES (3, 1, 1);

INSERT INTO habitaciones(id_reserva_actual, id_hotel, id_tipo_hab)
VALUES (4, 1, 5);

INSERT INTO habitaciones(id_reserva_actual, id_hotel, id_tipo_hab)
VALUES (5, 1, 1);

INSERT INTO habitaciones(id_reserva_actual, id_hotel, id_tipo_hab)
VALUES (5, 1, 2);

INSERT INTO habitaciones(id_reserva_actual, id_hotel, id_tipo_hab)
VALUES (5, 1, 3);

INSERT INTO habitaciones(id_reserva_actual, id_hotel, id_tipo_hab)
VALUES (6, 1, 6);

INSERT INTO habitaciones(id_reserva_actual, id_hotel, id_tipo_hab)
VALUES (7, 1, 2);

INSERT INTO habitaciones(id_reserva_actual, id_hotel, id_tipo_hab)
VALUES (8, 1, 5);

INSERT INTO habitaciones(id_reserva_actual, id_hotel, id_tipo_hab)
VALUES (NULL, 1, 1);

INSERT INTO habitaciones(id_reserva_actual, id_hotel, id_tipo_hab)
VALUES (NULL, 1, 3);

INSERT INTO habitaciones(id_reserva_actual, id_hotel, id_tipo_hab)
VALUES (NULL, 1, 4);

INSERT INTO habitaciones(id_reserva_actual, id_hotel, id_tipo_hab)
VALUES (NULL, 1, 4);

INSERT INTO habitaciones(id_reserva_actual, id_hotel, id_tipo_hab)
VALUES (NULL, 1, 4);

INSERT INTO habitaciones(id_reserva_actual, id_hotel, id_tipo_hab)
VALUES (NULL, 1, 6);
